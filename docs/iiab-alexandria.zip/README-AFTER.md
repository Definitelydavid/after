# Library of Alexandria (Internet-in-a-Box) — Hyper-Compressed Edition

Distributed via AFTER (https://after.training) for offline digital preservation.
Upstream repository: https://github.com/iiab/iiab
Tagline: "Build your own LIBRARY OF ALEXANDRIA with a Raspberry Pi !"

## What is this archive?
This bundle contains the complete Internet-in-a-Box (IIAB) software suite, Ansible roles,
playbooks, configurations, and offline knowledge service modules (Wikipedia, OpenStreetMap,
Kiwix, Khan Academy, Calibre, Medical/E-Books, Nextcloud, and offline mesh platforms).

## Quick Start
To install on a Raspberry Pi or Linux system:
  sudo ./iiab-install
Or run the interactive setup:
  sudo ./iiab-setup

For full documentation, see README.md and https://wiki.iiab.io
License: GPLv2+ / Open Source Free Knowledge
